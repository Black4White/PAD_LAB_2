

const mongoose = require("mongoose");

const vehicleSchema = new mongoose.Schema({
    regN: String,
    vin: String,
    color: String,
    owner: String,
    model: String,   
});

const car = mongoose.model('motercycleList',vehicleSchema);

module.exports = car;

